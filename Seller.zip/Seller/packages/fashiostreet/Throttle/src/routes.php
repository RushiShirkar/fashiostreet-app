<?php
Route::get('throttle/testing','fashiostreet\throttle\Controllers\ThrottleController@requesttesting');

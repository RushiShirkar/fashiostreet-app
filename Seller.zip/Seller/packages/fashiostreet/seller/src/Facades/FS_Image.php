<?php
namespace fashiostreet\seller\Facades;

use Illuminate\Support\Facades\Facade;

class FS_Image extends Facade
{
    protected static function getFacadeAccessor()
    {
        return 'FS_Image';
    }
}

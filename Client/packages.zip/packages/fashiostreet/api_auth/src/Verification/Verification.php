<?php

namespace fashiostreet\api_auth\Verification;

Use Illuminate\Database\Eloquent\Model;

class Verification extends Model
{
    protected $table = 'Verification';

}

<?php

namespace fashiostreet\api_auth\ResetPassword;

Use Illuminate\Database\Eloquent\Model;

class ResetPassword extends Model
{
    protected $table = 'userresetpassword';
}

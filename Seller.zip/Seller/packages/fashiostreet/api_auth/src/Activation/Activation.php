<?php

namespace fashiostreet\api_auth\Activation;

Use Illuminate\Database\Eloquent\Model;

class Activation extends Model
{
    protected $table = 'useractivation';

}

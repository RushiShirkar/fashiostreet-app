<?php
namespace fashiostreet\seller\Orders;
trait TrackerTrait{

}

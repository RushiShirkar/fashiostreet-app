<?php

namespace fashiostreet\product;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class userhistory extends Model
{
    protected $table = 'userhistory';

}
